<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(員工編號) AS max_employee_no FROM 員工";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxEmployeeNo = $row['max_employee_no'];
   $newEmployeeNo = $maxEmployeeNo + 1;
   $name=$_POST["姓名"];
   $job=$_POST["job"];
   $fm=$_POST["性別"];
   $bdate=$_POST["出生日期"];
   $usedate=$_POST["任用日期"];
   $addno=$_POST["區域號碼"];
   $add=$_POST["地址"];
   $tel=$_POST["分機號碼"];
   $boss="";
   if (strpos($job, "協理") !== false) 
      $boss = "1";
   if (strpos($job, "工程師") !== false) 
      $boss = "4";
   if (strpos($job, "業務") !== false) 
      $boss = "10";
   if (strpos($job, "經理") !== false) 
      $boss = "7";
   $in = "INSERT INTO 員工 (員工編號, 姓名, 職稱,性別,主管,出生日期,任用日期,區域號碼,地址,分機號碼) VALUES (";
    $in .= "'" . $newEmployeeNo . "','" . $_POST["姓名"] . "','";
    $in .= $_POST["job"] . "','" . $_POST["性別"] . "','" . $boss . "','" . $_POST["出生日期"] . "','";
    $in .= $_POST["任用日期"] . "','" . $_POST["區域號碼"] . "','";
    $in .= $_POST["地址"] . "','" . $_POST["分機號碼"] . "')";

   mysqli_query($link, 'SET NAMES utf8'); 
   if ( mysqli_query($link, $in) )
      echo "資料新增成功<br/>";
   else
      die("資料新增失敗<br/>");
}
?>
<form action="add.php" method="post">
<table border="1">
<h2>新增資料</h2>
<tr><td>姓名:</td>
   <td><input type="text" name="姓名" size="12"/></td>
</tr><tr><td>職稱:</td>
   <td><select name="job">
      <option value="工程師" selected="True">工程師	</option>
      <option value="工程助理">工程助理	</option>
      <option value="工程協理">工程協理	</option>
      <option value="業務助理">業務助理	</option>
      <option value="業務">	業務	</option>
      <option value="業務協理">業務協理	</option>
      <option value="總經理">總經理	</option>
   </td>
</tr><tr><td>性別:</td>
   <td><input type="radio" name="性別" value="男" checked="True"/>男
       <input type="radio" name="性別" value="女" checked="True"/>女</td>
</tr><tr><td>出生日期:</td>
   <td><input type="date" name="出生日期"/>
</tr><tr><td>任用日期:</td>
   <td><input type="date" name="任用日期" size="10"/>
</tr><tr><td>區域號碼:</td>
   <td><input type="text" name="區域號碼" size="10"/>
</tr><tr><td>地址:</td>
   <td><input type="text" name="地址" size="10"/>
</tr><tr><td>分機號碼:</td>
   <td><input type="text" name="分機號碼" size="10"/>
	 </td></tr>
</table>
<p>
<input type="submit" name="Insert" value="新增"/><hr>
<p>&nbsp</p>
</form>
<form method="post" action="employee.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>