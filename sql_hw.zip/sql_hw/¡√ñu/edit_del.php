<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>revise.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];
switch ($action) {
   case "update": 
      $name=$_POST["姓名"];
      $job=$_POST["職稱"];
      $fm=$_POST["性別"];
      $bdate=$_POST["出生日期"];
      $usedate=$_POST["任用日期"];   
      $addno=$_POST["區域號碼"];
      $add=$_POST["地址"];
      $tel=$_POST["分機號碼"];
   
      $sql = "UPDATE 員工 SET 姓名=
      '".$name."', 職稱='".$job."', 性別='".$fm."', 
      出生日期='".$bdate."', 任用日期='".$usedate."', 
      區域號碼='".$addno."', 地址='".$add."', 
      分機號碼='".$tel."'WHERE 員工編號='".$id."'";
      mysqli_query($link, $sql);
      echo "修改完成!";
      break;
   case "del": 
      $sql = "DELETE FROM 員工 WHERE 員工編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      break;
   case "edit":
      $sql = "SELECT*FROM 員工 WHERE 員工編號='".$id."'";
      $result = mysqli_query($link, $sql);
      $row = mysqli_fetch_assoc($result);
      $name=$row["姓名"];
      $job=$row["職稱"];
      $fm=$row["性別"];
      $bdate=$row["出生日期"];
      $usedate=$row["任用日期"];   
      $addno=$row["區域號碼"];
      $add=$row["地址"];
      $tel=$row["分機號碼"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">姓名: </font></td>
   <td><input type="text" name="姓名" size="25"
   maxlength="10" value="<?php echo $name ?>"/></td></tr>
<tr><td><font size="2">性別: </font></td>
    <td><input type="text" name="性別" size="10"
    maxlength="10" value="<?php echo $fm ?>"/></td></tr>
<tr><td><font size="2">職稱: </font></td>
   <td><input type="text" name="職稱" size="10"
    maxlength="10" value="<?php echo $job ?>"/></td></tr>
<tr><td><font size="2">出生日期: </font></td>
   <td><input type="text" name="出生日期" size="25"
   maxlength="10" value="<?php echo $bdate ?>"/></td></tr>
<tr><td><font size="2">任用日期: </font></td>
   <td><input type="text" name="任用日期" size="25"
   maxlength="10" value="<?php echo $usedate ?>"/></td></tr>
<tr><td><font size="2">區域號碼: </font></td>
   <td><input type="text" name="區域號碼" size="25"
   maxlength="10" value="<?php echo $addno ?>"/></td></tr>
<tr><td><font size="2">地址: </font></td>
   <td><input type="text" name="地址" size="25"
   maxlength="10" value="<?php echo $add ?>"/></td></tr>
<tr><td><font size="2">分機號碼 : </font></td>
   <td><input type="text" name="分機號碼" size="20"
   maxlength="20" value="<?php echo $tel ?>"/></td></tr>
<tr><td><input type="submit"  value="更新連絡資料"/></td></tr>
</table>
</form>
<?php   
       break;
} 
?>

<form method="post" action="employee.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>