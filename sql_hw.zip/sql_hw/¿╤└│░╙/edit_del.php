<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>revise.php</title>
</head>
<body>
<?php
require_once("open.inc");
$id = $_GET["id"];
$action = $_GET["action"];
switch ($action) {
   case "update":
      $sname=$_POST["供應商名稱"];
      $name=$_POST["聯絡人"];
      $job=$_POST["聯絡人職稱"];
      $fm=$_POST["聯絡人性別"];
      $addno=$_POST["郵遞區號"];
      $add=$_POST["地址"];
      $tel=$_POST["電話"];
   
      $sql = "UPDATE 供應商 SET 供應商名稱=
      '".$sname."', 聯絡人='".$name."', 聯絡人職稱='".$job."', 聯絡人性別='".$fm."', 
      郵遞區號='".$addno."', 地址='".$add."', 電話='".$tel."'WHERE 供應商編號='".$id."'";
      mysqli_query($link, $sql);
      echo "修改完成!";
      break;
   case "del": 
      $sql = "DELETE FROM 供應商 WHERE 供應商編號='".$id."'";
      mysqli_query($link, $sql);
      echo "成功刪除資料!";
      break;
   case "edit":
      $sql = "SELECT*FROM 供應商 WHERE 供應商編號='".$id."'";
      $result = mysqli_query($link, $sql);
      $row = mysqli_fetch_assoc($result);
      $sname=$row["供應商名稱"];
      $name=$row["聯絡人"];
      $job=$row["聯絡人職稱"];
      $fm=$row["聯絡人性別"];
      $addno=$row["郵遞區號"];
      $add=$row["地址"];
      $tel=$row["電話"];
?>
<form action="edit_del.php?action=update&id=<?php echo $id ?>"method="post">
<table border="1">
<tr><td><font size="2">供應商名稱: </font></td>
   <td><input type="text" name="供應商名稱" size="12"
   maxlength="10" value="<?php echo $sname ?>"/></td></tr>
<tr><td><font size="2">聯絡人: </font></td>
   <td><input type="text" name="聯絡人" size="25"
   maxlength="10" value="<?php echo $name ?>"/></td></tr>
<tr><td><font size="2">聯絡人性別: </font></td>
    <td><input type="text" name="聯絡人性別" size="10"
    maxlength="10" value="<?php echo $fm ?>"/></td></tr>
<tr><td><font size="2">聯絡人職稱: </font></td>
   <td><input type="text" name="聯絡人職稱" size="10"
    maxlength="10" value="<?php echo $job ?>"/></td></tr>
<tr><td><font size="2">郵遞區號: </font></td>
   <td><input type="text" name="郵遞區號" size="25"
   maxlength="10" value="<?php echo $addno ?>"/></td></tr>
<tr><td><font size="2">地址: </font></td>
   <td><input type="text" name="地址" size="25"
   maxlength="10" value="<?php echo $add ?>"/></td></tr>
<tr><td><font size="2">電話 : </font></td>
   <td><input type="text" name="電話" size="20"
   maxlength="20" value="<?php echo $tel ?>"/></td></tr>
<tr><td><input type="submit"  value="更新連絡資料"/></td></tr>
</table>
</form>
<?php   
       break;
} 
?>
<form method="post" action="supplier.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>