<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(供應商編號) AS max_supplier_no FROM 供應商";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxSupplierNo = $row['max_supplier_no'];
   
   $num = substr($maxSupplierNo, 4);
   $newNum = intval($num) + 1;
   $newSupplierNo = "S000" . $newNum;
   $sname=$_POST["供應商名稱"];
   $name=$_POST["聯絡人"];
   $job=$_POST["job"];
   $fm=$_POST["性別"];
   $addno=$_POST["郵遞區號"];
   $add=$_POST["地址"];
   $tel=$_POST["電話"];
   
   $in ="INSERT INTO 供應商 (供應商編號, 供應商名稱, 聯絡人,聯絡人性別,聯絡人職稱,郵遞區號,地址,電話) VALUES (";
   $in.="'" . $newSupplierNo ."','".$_POST["供應商名稱"]."','";
   $in.=$_POST["聯絡人"]."','".$_POST["性別"]."','";
   $in.=$_POST["job"]."','".$_POST["郵遞區號"]."','";
   $in.=$_POST["地址"]."','".$_POST["電話"]."')";

   mysqli_query($link, 'SET NAMES utf8'); 
   if ( mysqli_query($link, $in) )
      echo "資料新增成功<br/>";
   else
      die("資料新增失敗<br/>");
}
?>
<form action="add.php" method="post">
<table border="1">
<h2>新增資料</h2>
<tr><td>供應商名稱:</td>
   <td><input type="text" name="供應商名稱" size="12"/></td>
</tr><tr><td>聯絡人:</td>
   <td><input type="text" name="聯絡人" size="25"/></td>
</tr><tr><td>聯絡人性別:</td>
    <td><input type="radio" name="性別" value="男" checked="True"/>男
        <input type="radio" name="性別" value="女" />女</td>
</tr><tr><td>聯絡人職稱:</td>
    <td><select name="job">
      <option value="業務" selected="True">業務	</option>
      <option value="董事長">董事長	</option>
      <option value="訂貨員">訂貨員	</option>
   </td>
</tr><tr><td>郵遞區號:</td>
   <td><input type="text" name="郵遞區號" size="10"/>
</tr><tr><td>地址:</td>
   <td><input type="text" name="地址" size="10"/>
</tr><tr><td>電話:</td>
   <td><input type="text" name="電話" size="10"/>
	 </td></tr>
</table>
<input type="submit" name="Insert" value="新增"/>
</form>
<form method="post" action="supplier.php">
<input type="submit" name="home" value="回首頁"/>
</form>

</body>
</html>