<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>add.php</title>
</head>
<body>
<?php
require_once("open.inc");
if (isset($_POST["Insert"])) {
   $sql_1 = "SELECT MAX(客戶編號) AS max_client_no FROM 客戶";
   $result = mysqli_query($link, $sql_1);
   $row = mysqli_fetch_assoc($result);
   $maxClientNo = $row['max_client_no'];
   
   $num = substr($maxClientNo, 3);
   $newNum = intval($num) + 1;
   $newClientNo = "C00" . $newNum;
   $cname=$_POST["公司名稱"];
   $name=$_POST["聯絡人"];
   $job=$_POST["job"];
   $fm=$_POST["性別"];
   $addno=$_POST["郵遞區號"];
   $add=$_POST["地址"];
   $tel=$_POST["電話"];
   
   $in ="INSERT INTO 客戶 (客戶編號, 公司名稱, 聯絡人,聯絡人職稱,聯絡人性別,郵遞區號,地址,電話) VALUES (";
   $in.="'" . $newClientNo ."','".$_POST["公司名稱"]."','";
   $in.=$_POST["聯絡人"]."','".$_POST["job"]."','";
   $in.=$_POST["性別"]."','".$_POST["郵遞區號"]."','";
   $in.=$_POST["地址"]."','".$_POST["電話"]."')";

   mysqli_query($link, 'SET NAMES utf8'); 
   if ( mysqli_query($link, $in) )
      echo "資料新增成功<br/>";
   else
      die("資料新增失敗<br/>");
}
?>
<form action="add.php" method="post">
<table border="1">
<h2>新增資料</h2>
<tr><td>公司名稱:</td>
   <td><input type="text" name="公司名稱" size="12"/></td>
</tr><tr><td>聯絡人:</td>
   <td><input type="text" name="聯絡人" size="12"/></td>
</tr><tr><td>聯絡人職稱:</td>
   <td><select name="job">
      <option value="業務" selected="True">業務	</option>
      <option value="董事長">董事長	</option>
      <option value="訂貨員">訂貨員	</option>
      <option value="行銷專員">行銷專員	</option>
      <option value="會計人員">	會計人員	</option>
      <option value="業務助理">業務助理	</option>
   </td>
</tr><tr><td>聯絡人性別:</td>
   <td><input type="radio" name="性別" value="男" checked="True"/>男
       <input type="radio" name="性別" value="女" />女</td>
</tr><tr><td>郵遞區號:</td>
   <td><input type="text" name="郵遞區號" size="10"/>
</tr><tr><td>地址:</td>
   <td><input type="text" name="地址" size="10"/>
</tr><tr><td>電話(ex:(0X)-xxx-xxxx):</td>
   <td><input type="text" name="電話" size="10"/>
	 </td></tr>
</table>
<p>
<input type="submit" name="Insert" value="新增"/><hr>
</form>
<form method="post" action="client.php">
<input type="submit" name="home" value="回首頁"/><hr>
</form>
</body>
</html>